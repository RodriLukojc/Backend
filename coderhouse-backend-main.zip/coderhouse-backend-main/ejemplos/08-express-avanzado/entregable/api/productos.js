class Productos {
    constructor() {
        // incializar variables
    }

    // agregar los metodos requeridos
}

// exporto una instancia de la clase
module.exports = new Productos();