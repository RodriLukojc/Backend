const fs = require('fs');

fs.unlinkSync('./archivo.txt');
