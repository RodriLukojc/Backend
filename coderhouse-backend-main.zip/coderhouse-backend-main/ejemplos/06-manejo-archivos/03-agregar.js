const fs = require('fs');

fs.appendFileSync('./archivo.txt', 'Contenido agregado en el archivo');
