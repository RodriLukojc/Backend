/**
 * Desafio generico - tiempo 5/10 minutos
 * Guardar en un archivo fyh.txt la hora actual y leerlo usand operaciones sync
 */
const fs = require('fs');

function escribir(ruta, data) {

}

function leer(ruta) {

}
