const fs = require('fs');

fs.writeFileSync('./archivo.txt', 'El contenido se sobreescribio en el archivo');
