/**
 * Desafio de programación
 * Definir una funcion operacion que reciba como parametros dos valores y una funcion con la operacion
 * a realizar, debe devolver el resultado.
 * Definir las funciones: suma, resta, multiplicacion, division y modulo. Reciben dos parametros 
 * y devuelven el resultado.
 * Todas las funciones deben realizarse con funciones flecha.
 */

const suma = (numero1, numero2) => {

}

const resta = (numero1, numero2) => {

}

const multiplicacion = (numero1, numero2) => {

}

const division = (numero1, numero2) => {

}

const modulo = (numero1, numero2) => {

}

const operacion = (numero1, numero2, op) => {

}

console.log(operacion(4, 2, suma));
console.log(operacion(6, 2, resta));
console.log(operacion(4, 4, multiplicacion));
console.log(operacion(10, 2, division));
console.log(operacion(5, 2, modulo));
