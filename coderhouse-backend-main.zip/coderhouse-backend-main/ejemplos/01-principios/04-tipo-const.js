/**
 * ejemplo de una variable declarada con const
 * al ser una constante, no puede ser modificada una vez que fue declarada
 */
const i = 0;

i = 1; // tira error
