/**
 * ejemplo de una funcion IIFE (Inmediately Invoked Function Expressions) (no ife)
 * se ejecuta tan pronto como se define
 */
(function(a, b) {
    console.log(a + b);
})(2, 3);
