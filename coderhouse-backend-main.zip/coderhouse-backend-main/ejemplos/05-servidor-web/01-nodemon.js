let a = 5;
let b = 3;
let c = 5 + 10;

console.log(c);
