// boolean
let done : boolean = false;

// number
let decimal: number = 6;
let hex: number = 0xf00d;
let binary: number = 0b1010;
let octal: number = 0o744;

// string
let color: string = "blue";
color = "red";

// array
let lista: number[] = [1, 2, 3];
let lista2: Array<number> = [4, 5, 6];

console.log(lista);
