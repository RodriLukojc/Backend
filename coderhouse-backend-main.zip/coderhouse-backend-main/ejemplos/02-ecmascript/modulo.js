export function saludar() {
    console.log('Hola!');
}