/**
 * Realizaremos una funcion que reciba un objeto y muestre cada
 * dos segundos sus claves y valores en este formato: [clave, valor]
 * Usar: entries, async y await
 */

async function esperar(segundos) {

}

async function mostrar(objeto) {

}
