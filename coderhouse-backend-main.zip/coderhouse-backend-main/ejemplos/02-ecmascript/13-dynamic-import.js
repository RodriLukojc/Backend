/**
 * ejemplo de uso del import/export para modulos
 */
import { saludar } from './modulo';
saludar();
