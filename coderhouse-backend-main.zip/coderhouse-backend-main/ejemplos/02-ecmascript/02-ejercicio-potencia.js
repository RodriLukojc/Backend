/**
 * Realizar una funcion que devuelva un array y devuelva el resultado de
 * la operacion de potenciacion en caso de poder realizarla.
 * De no ser posible, devolver null.
 * Consejo: se puede usar eval(exp) y array.includes
 */
var array = ['6**2', '**', '3**3', '4**', '4**5', '8**2**', '4*=5'];

array.forEach(exp => {
    // completar el codigo
});
