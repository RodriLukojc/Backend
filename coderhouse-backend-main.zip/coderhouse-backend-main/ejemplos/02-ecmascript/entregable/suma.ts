export class Suma {

    // completar con variables privadas
    
    constructor(a: number, b: number) {
       // completar el constructor
    }

    resultado(): number {
        // completar con la logica
        return 0;
    }
}